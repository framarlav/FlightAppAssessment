package com.assesment.booking;

public class payload {
	
	public static String addBooking()
	{
		return "{\r\n"
				+ "  \"name\":\"Marcos\",\r\n"
				+ "  \"surname\":\"Alonso\",\r\n"
				+ "  \"nationality\":\"Spanish\",\r\n"
				+ "  \"identification\":\"20114529P\",\r\n"
				+ "  \"age\":28,\r\n"
				+ "  \"price\":\"560.00f\",\r\n"
				+ "  \"id_flight\":1\r\n"
				+ "}";

	}
}
