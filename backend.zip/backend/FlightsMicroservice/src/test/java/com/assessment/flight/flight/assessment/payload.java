package com.assessment.flight.flight.assessment;

public class payload {
	public static String addFlight()
	{
		return "{\r\n"
				+ "  \"id\":3,\r\n"
				+ "  \"airline\":\"Iberia\",\r\n"
				+ "  \"date\":\"2022-10-31\",\r\n"
				+ "  \"origin\":\"Sevilla\",\r\n"
				+ "  \"destination\":\"Madrid\",\r\n"
				+ "  \"scales\":null,\r\n"
				+ "  \"luggage\":true\r\n"
				+ "}";

	}
}
