package com.example.analyticalInfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AnalyticalInfoApplication {

	public static void main(String[] args) {
		SpringApplication.run(AnalyticalInfoApplication.class, args);
	}

}
