import React from "react";
import logo from "./logo.svg";
import "./App.css";
import Booking from "./componentes/Booking";
import TripList from "./componentes/TripList";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import BookingData from "./componentes/BookingData";
import Navbarflight from "./componentes/Navbarflight";
import AboutUs from "./componentes/AboutUs";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path='/' element={<Navbarflight/>}>
        <Route index element={<Booking />}></Route>
        <Route path ='about' element={<AboutUs/>}/>
        <Route path="/trips" element={<TripList/>}></Route> 
        <Route path="/booking" element={<BookingData/>}></Route> 
        <Route path='*' element={<Navigate replace to="/"/>}/>
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
