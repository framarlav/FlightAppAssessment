import React from 'react';
import logo from './logo.svg';
import './App.css';
import Booking from './componentes/Booking';



  function App() {
    return (
      <React.Fragment >
        <Booking/>
                           
      </React.Fragment>
       
         
    
    );
  }
  


export default App;
